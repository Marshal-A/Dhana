interface profile {
    userId:number;
	first_name:string;
	last_name:string;
	mobile_no:string;
	age:number;
    username:string;
	password:string;
	gender:string;
}