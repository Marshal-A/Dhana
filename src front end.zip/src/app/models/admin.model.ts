export interface admin {
    admin:string,
    password:string
}