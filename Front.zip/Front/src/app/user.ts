export class User {
    id:number;
    emailId:string;
    userName:string;
    password:string;
   // constructor(){}
}
